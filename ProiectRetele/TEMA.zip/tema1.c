#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<unistd.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<string.h>
#include<sys/wait.h>
#include <sys/socket.h>
#include <time.h>

#define mesaj1 "quit\n"
#define mesaj2 "Asteptati 2 secunde pentru a iesi !"
#define mesaj3 "Comanda gresita !"
#define mesaj4 "mystat"

char comanda [1024];

void status(char x[10])
{
   struct stat informatii;
   int deschide;
   deschide = stat(x,&informatii);
   printf("%s%o\n"," Numar de inoduri : ",informatii.st_ino);
   printf("%s%d\n"," Numar de linkuri : ",informatii.st_nlink);
   printf("%s%s"," Ultima data de acces : ", ctime(&informatii.st_atime));
}


void Quit_function()
{
	int canal[2],proces;
	char mesaj[1024];
    fflush(stdout);//golire buffer

	if (socketpair(AF_UNIX, SOCK_STREAM,0,canal) <0 )
	{
		perror("Eroare la socketpair");
		exit(1);
	}

	proces = fork();
	if (proces==-1) perror("Eroare la fork");
	else if (proces>0)
	{
         close (canal[0]);//comunici prin 1
         //scanf("%s",comanda);
         if (write(canal[1],comanda , sizeof(comanda))<0) perror("Eroare la scriere in copil");
         if (read(canal[1],mesaj,1024)<0) perror("Eroare la citire in parinte");
         printf("%s\n",mesaj);
         if (strcmp(mesaj,mesaj2)==0) sleep(2);
         close (canal[1]);
         wait(NULL);
     }
    else 
    {
    	 close (canal[1]);
    	 //if (write(canal[0],mesaj2,sizeof(mesaj2))<0) perror("Eroare la scrierea in copil");
    	 if (read(canal[0],mesaj,1024)<0) perror("Eroare la citire in copil");
    	 if(strcmp (mesaj,mesaj1)==0)  {  
                                         if (write(canal[0],mesaj2,sizeof(mesaj2))<0) perror("Eroare la scrierea in copil");
    	 	                             sleep(2);
                                         exit(0);
    	                               }
    	 else (write(canal[0],mesaj3,sizeof(mesaj3)));
    	 close (canal[0]);
    	 exit(0);
    }
}

void primeste_comanda(char nume[20])
{
	
             
    printf("%s%s%s","root@",nume,":");
    if(fgets (comanda,1024, stdin)==0)
    {
    	printf("\n");//pentru comanda ctrl+d
	    exit(1);
    }
    if (strcmp(comanda,mesaj1)==0)//verificam daca comanda introdusa nu este chiar quit 
    {
      Quit_function();
    }
    else {
    char *x = strtok(comanda," ");
    char *y= strtok(NULL,"\n");
    if (strncmp(comanda,mesaj4,strlen(mesaj4))==0)
    {   
        status(y);
    	primeste_comanda(nume);
    }
    else 
    {
     
      printf("Comanda gresita, mai incearca\n");
      primeste_comanda(nume);
    }
    }
    exit(1);

             
}
void quit()
{   
   
	printf ("Ati ales sa iesiti !\n");
    sleep(1);
	exit(1);
}
void Login()
{  
   FILE *deschide;
   int 	canal_tata_fiu[2],canal_fiu_tata[2];
   char buffer[20],primire[20],primire_copil[20],nume_de_utilizator[20];
   printf ("%s","Introduceti un nume de utilizator valid:");
		fflush(stdout);//golire buffer
	        { 
		      
		      pipe(canal_tata_fiu);
	          pipe(canal_fiu_tata);	  
              pid_t proces = fork();// login 
              if(proces<0) perror("Eroare la fork");

          	  else if (proces>0){ //tatal care primeste comanda si o transmite fiului;
	                     
	        		              if(fgets(nume_de_utilizator,100,stdin)==0)
	        		              {
	        		              	printf("\n");//pentru comanda ctrl+d
	                                exit(1);
	        		              }//input
	        		              char *x=strtok(nume_de_utilizator,"\n");
	        		              write(canal_tata_fiu[1],x,30); //trimiterea inputului catre copil
	        		              read(canal_fiu_tata[0],primire_copil,30);
	        		              printf("%s\n",primire_copil);
	        		              if (strcmp(primire_copil,"Utilizator conectat !")==0)
	        		            {
	        		          	  primeste_comanda(x);
	        		            }
				                  wait(NULL);
	
		 	                    } 
          	  else{  
          	  	     read (canal_tata_fiu[0],primire,20);
	        		 deschide=fopen("useri.txt","r");
	        		 if (deschide!=NULL){
                     while (!feof(deschide)){
                                               
                                               fscanf (deschide, "%s",buffer);
                                               if (strcmp(buffer,primire)==0) break;
                                             
                                            }
                     }
                     fclose (deschide);
	  			     if (strcmp(buffer,primire)==0){ 
	  			     	                              
	  			                                      write(canal_fiu_tata[1],"Utilizator conectat !",30);
				                                    }
				     else{ 
				     	   //printf("%d",strlen(LoginFail));
					       printf("Logare esuata!\n");
					       Login();
					       }
				    exit(0);
	                          
       	          }
		    } 
}        

void Introducere (char ComandaInitiala[20])
{	
	printf ("Tap login or exit : ");
	if(fgets(ComandaInitiala,100,stdin)==0) { 
		                                        printf("\n");//pentru comanda ctrl+d
	                                            exit(1);
	                                        }
}
void Comanda(char text[30])
{   
    char *x=strtok(text,"\n");
	int variabila;
	if ((strcmp(x,"exit"))==0) variabila=1;
	else if ((strcmp(x,"login"))==0) variabila=0;
	 

	switch (variabila)
	{
     case 0: 
         Login();
         break;
     case 1:
         quit();
         break;
     default:
         printf("Comanda necunoscuta\n");
         Introducere(text);
         Comanda(text);
         break;

   }
}

int main (int argc,char *argv[])
{   
   
   char x[20];
   Introducere(x);
   Comanda(x);
   
}
